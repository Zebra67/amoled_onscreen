java -jar crowdin-cli.jar download
