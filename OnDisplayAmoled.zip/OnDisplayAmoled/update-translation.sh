java -jar crowdin-cli.jar upload sources
